package application;

/* 	
 *  connectfive
 *  army ants - software engineering
 *  copmuterplayer class
 */

import java.util.Random;

/******************************************************************************************************************************************************/
/*****The computer player will need to decide when to play to win and when to play not-to-lose (defensively). Playing to win ********/
/*****will take priority. We will accomplish this by scanning the gameboard. If the human player has 4 consecutive slots ************/
/*****(vertically, horizontally, or diagonally), the computer will play defensively. Otherwise, the computer player will play to win.*****/
/*****************************************************************************************************************************************************/
public class ComputerPlayer {

    int[] coordsToPlay;
    boolean moveChosen;
    boolean winningMove;
    boolean verbose = true; // Switch to turn on/off debugging messages

    ComputerPlayer() {
        this.coordsToPlay = new int[2];
        this.moveChosen = false;
        this.winningMove = false;
    }

    public int[] chooseMove(Gameboard gameboard) {

	/* 
         * The methods we use for scanning the board take not only the gameboard, but also take a target and playerIdentifier variables as parameters.
         * The target is how many in a row we're searching for during that particular method call. playerIdentifier is 2 for computer player and 1 for human player.
         * This is how we'll determine consecutive holdings on the board.
	 * Give priority to vertical play. If the human player has 4 consecutive chips vertically, the
         * computer will play there. Otherwise, we'll process the board laterally and diagonally.
         */
        int playerIdentifier, target;
        moveChosen = false;
        winningMove = false;

        // First we need to make sure the computer doesn't have a winning move somewhere.

        target = 4;
        playerIdentifier = 2;
        checkVertical(gameboard, target, playerIdentifier);
        if (!winningMove) {
            checkLateral(gameboard, target, playerIdentifier);
        }
        if (!winningMove) {
            checkDiagonal(gameboard, target, playerIdentifier);
        }
        if (winningMove) {
            return coordsToPlay;
        }

        /* 
         * If no immediate winning move, we'll check our defensive options. If the human player
         * has 4 in a row anywhere and we can make an immediate block, this will take priority                              ********
         */
        playerIdentifier = 1; // How we're detecting consecutive holdings. 1 = human player
        target = 4; // When we're playing defensively, we only make a blocking play if the human player has 4 in a row
        checkVertical(gameboard, target, playerIdentifier);
        if (!moveChosen) {
            checkLateral(gameboard, target, playerIdentifier);
        }
        if (!moveChosen) {
            checkDiagonal(gameboard, target, playerIdentifier);
        }

        // If the human player didn't have 4 in a row anywhere the computer will play to win
         playerIdentifier = 2;
        target = 4; // We'll start looking for 4 consecutive computer slots, then 3, etc. The computer will make it's move where it has the highest current streak
        while (target > 0 && !moveChosen) {
            if (!moveChosen) {
                checkVertical(gameboard, target, playerIdentifier);
            }
            if (!moveChosen) {
                checkLateral(gameboard, target, playerIdentifier);
            }
            if (!moveChosen) {
                checkDiagonal(gameboard, target, playerIdentifier);
            }
            target--;
        }

        // If still no move chosen, the board is blank. Choose random coordinates
        if (!moveChosen) {
            getRandomCoordinates(gameboard);
        }

        /**
         * **************************************************************************************************************
         */
        /*       REQUIREMENTS 6.2.1.5 - Return the coordinates to play 	*/
        /**
         * *************************************************************************************************************
         */
        //Finally, return the variable coordsToPlay 
        return coordsToPlay;
        /**
         * ********************* END Requirement 6.2.1.5 ******************************
         */
    }

    /**
     * *****************************************************************************************************************
     */
    /*           REQUIREMENT 6.2.1.1  - Scan the board vertically                  */
    /**
     * *****************************************************************************************************************
     */
    private void checkVertical(Gameboard gameboard, int target, int playerIdentifier) {
        if (verbose) {
            System.out.println("Check vertical with player = " + playerIdentifier);
        }

        outerloop:
        for (int i = 0; i < gameboard.getColumns(); i++) {
            int consecutive = 0;
            for (int j = 0; j < gameboard.getRows(); j++) {
                if (gameboard.getSlots(i, j) == playerIdentifier) {
                    consecutive++;
                } else {
                    consecutive = 0;
                }
                if (consecutive == target && j < gameboard.getRows() - 1
                        && gameboard.getSlots(i, j + 1) == 0) {
                    if (playerIdentifier == 2 && target == 4) {
                        winningMove = true;
                    }
                    coordsToPlay[0] = i;
                    coordsToPlay[1] = j + 1;
                    moveChosen = true;
                    if (verbose) {
                        System.out.println("Coordinates set in vertical");
                    }
                    break outerloop;
                }
            }
        }
    }

    /**
     * ************** END Requirement 6.2.1.1                             *******************************
     */

    /**
     * *****************************************************************************************************************
     */
    /*          REQUIREMENT 6.2.1.2 - Scan the board laterally                              */
    /**
     * *****************************************************************************************************************
     */
    private void checkLateral(Gameboard gameboard, int target, int playerIdentifier) {
        /* Go through each row looking for consecutive chips held by the
         * "playerIdentifier." If we find "target" in a row going forward, we'll play the coordinates to the right of the slot.
         * If we find "target" in a row going backward, we'll play the coordinates to the left of the slot.
         */
        if (verbose) {
            System.out.println("Checking Lateral with player = " + playerIdentifier);
        }

        outerloop:

        for (int i = 0; i < gameboard.getRows(); i++) {

            // Go forward across the row
            int consecutive = 0;
            for (int j = 0; j < gameboard.getColumns(); j++) {
                if (gameboard.getSlots(j, i) == playerIdentifier) {
                    consecutive++;
                    if (verbose) {
                        System.out.println("Consecutive = " + consecutive);
                        System.out.println("j = " + j + " , i = " + i);
                    }
                } else {
                    consecutive = 0;
                }

                if (consecutive == target) {
                    if (j < gameboard.getColumns() - 1) { // If j is currently less than 6, meaning at most we're at the 6th column.
                        if (gameboard.getSlots(j + 1, i) == 0) {// If the slot immediately to the right of the "target" consecutive chips is unoccupied, we'll see if a play there is a good move.
                            if (i == 0) {// If we're on the bottom row, go ahead and make the play
                                if (playerIdentifier == 2 && target == 4) {
                                    winningMove = true;
                                }
                                coordsToPlay[0] = j + 1;
                                coordsToPlay[1] = i;
                                moveChosen = true;
                                if (verbose) {
                                    System.out.println("Coordinates set in lateral at i = 0");
                                }
                                break outerloop;
                            } else if (gameboard.getSlots(j + 1, i - 1) != 0) {// If the slot immediately beneath where we want to play is occupied, go ahead and make the play
                                if (playerIdentifier == 2 && target == 4) {
                                    winningMove = true;
                                }
                                coordsToPlay[0] = j + 1;
                                coordsToPlay[1] = i;
                                moveChosen = true;
                                System.out.println("Coordinates set in lateral in slot underneath i = 0");
                                break outerloop;
                            } else if (i >= 2 && playerIdentifier == 2) {
				// If all above fails, only play that column if there are two empty slots down the column UNDER the position AND only if we're playing to win. 
                                //We won't worry about blocking the human player unless our play provides an immediate block.
                                if (verbose) {
                                    System.out.println("j = " + j + ", i = " + i);
                                }
                                if (i == 2 && gameboard.getSlots(j + 1, i - 2) == 0) {
                                    coordsToPlay[0] = j + 1;
                                    coordsToPlay[1] = i - 2;
                                    moveChosen = true;
                                    if (verbose) {
                                        System.out.println("Coordinates set in lateral at i = 2. Target = " + target);
                                    }
                                    break outerloop;
                                } else if (gameboard.getSlots(j + 1, i - 2) == 0 && gameboard.getSlots(j + 1, i - 3) != 0) {
                                    coordsToPlay[0] = j + 1;
                                    coordsToPlay[1] = i - 2;
                                    moveChosen = true;
                                    if (verbose) {
                                        System.out.println("Coordinates set in lateral at i > 2");
                                    }
                                    break outerloop;
                                }
                            }
                        }
                    }
                }
            }

            // Go backward across row
            consecutive = 0;
            for (int k = gameboard.getColumns() - 1; k >= 0; k--) {
                if (gameboard.getSlots(k, i) == playerIdentifier) {
                    consecutive++;
                } else {
                    consecutive = 0;
                }
                if (consecutive == target) {
                    if (k > 0) {// Making sure we're not at the leftmost column
                        // If the slot to the left is empty, add it to the list of potential plays
                        if (gameboard.getSlots(k - 1, i) == 0) {
                            if (i == 0) {// If we're on the bottom row, go ahead
                                // and make the play
                                if (playerIdentifier == 2 && target == 4) {
                                    winningMove = true;
                                }
                                coordsToPlay[0] = k - 1;
                                coordsToPlay[1] = i;
                                moveChosen = true;
                                break outerloop;
                            } else if (gameboard.getSlots(k - 1, i - 1) != 0) {// If the slot immediately beneath where we want to play is occupied, go ahead and make the play
                                if (playerIdentifier == 2 && target == 4) {
                                    winningMove = true;
                                }
                                coordsToPlay[0] = k - 1;
                                coordsToPlay[1] = i;
                                moveChosen = true;
                                break outerloop;
                            } else if (i >= 2 && playerIdentifier == 2) {
                                if (i == 2
                                        && gameboard.getSlots(k - 1, i - 2) == 0) {
                                    coordsToPlay[0] = k - 1;
                                    coordsToPlay[1] = i - 2;
                                    moveChosen = true;
                                    break outerloop;
                                } else if (gameboard.getSlots(k - 1, i - 2) == 0
                                        && gameboard.getSlots(k - 1, i - 3) != 0) {
                                    coordsToPlay[0] = k - 1;
                                    coordsToPlay[1] = i - 2;
                                    moveChosen = true;
                                    break outerloop;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * ************** END Requirement 6.2.1.2 *******************************
     */

    /**
     * *****************************************************************************************************************
     */
    /*          REQUIREMENT 6.2.1.3 - Scan the board laterally                                     */
    /**
     * *****************************************************************************************************************
     */
    private void checkDiagonal(Gameboard gameboard, int target, int playerIdentifier) {

        System.out.println("STILL HAVE AN ISSUE WITH DIAGONALS");

        // Check forward
        outerloop:
        for (int i = 0; i < 2; i++) {// Rows
            for (int j = 0; j < 3; j++) {// Columns
                if (gameboard.getSlots(j, i) == playerIdentifier) {
                    if (checkDiagonalForward(j, i, playerIdentifier, target, gameboard)) {
                        moveChosen = true;
                        if (verbose) {
                            System.out.println("Coordinates set in diagonal, checkForward");
                        }
                        break outerloop;
                    }
                }
            }
        }

        // Check backward
        if (!moveChosen) {
            outerloop:
            for (int i = 0; i < 2; i++) {// Rows
                for (int j = 6; j > 3; j--) {// Columns
                    if (gameboard.getSlots(j, i) == playerIdentifier) {
                        if (checkDiagonalBackward(j, i, playerIdentifier, target, gameboard)) {
                            moveChosen = true;
                            if (verbose) {
                                System.out.println("Coordinates set in diagonal, checkBackward");
                            }
                            break outerloop;
                        }
                    }
                }
            }
        }
    }

    private boolean checkDiagonalForward(int j, int i, int playerIdentifier, int target, Gameboard gameboard) {
        int count = 1; // We'll set it as 1 because when we call this method we
        // already have 1 "in a row"
        for (int k = 1; k < 5; k++) {
            if (gameboard.getSlots(j + k, i + k) == playerIdentifier) {
                count++;
            } else {
                count = 1;
            }
            if (count == target && ((j + k + 1) < gameboard.getColumns()) && ((i + k + 1) < gameboard.getRows()) && (gameboard.getSlots((j + k + 1), (i + k + 1)) == 0)) {// If there 'target' in a row and we're not already at the top row or the last column
                if (checkColumnPosition(j + k + 1, i + k + 1, target, playerIdentifier, gameboard)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean checkDiagonalBackward(int j, int i, int playerIdentifier, int target, Gameboard gameboard) {
        int count = 1; // We'll set it as 1 because when we call this method we already have 1 "in a row"
        for (int k = 1; k < 5; k++) {
            if (gameboard.getSlots(j - k, i + k) == playerIdentifier) {
                count++;
            } else {
                count = 1;
            }
            if (count == target && (j - k + i) > 0 && (i + k + 1) < gameboard.getRows() && (gameboard.getSlots((j - k + 1), (i + k + 1)) == 0)) {
                if (checkColumnPosition(j - k + 1, i + k + 1, target, playerIdentifier, gameboard)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean checkColumnPosition(int j, int i, int target, int playerIdentifier, Gameboard gameboard) {
        if (gameboard.getSlots(j, i - 1) != 0) {// If the slot directly underneath is occupied, make the play
            if (playerIdentifier == 2 && target == 4) {
                winningMove = true;
            }
            coordsToPlay[0] = j;
            coordsToPlay[1] = i;
            return true;
        } else if (gameboard.getSlots(j, i - 2) == 0
                && gameboard.getSlots(j, i - 3) != 0) {// If the slot 2 underneath is open, make the play
            coordsToPlay[0] = j;
            coordsToPlay[1] = i - 2;
            return true;
        }
        return false;
    }

    /**
     * ************** END Requirement 6.2.1.3       ****************************
     */

    /**
     * *****************************************************************************************************************
     */
    /*                REQUIREMENT 6.2.1.4 - Get random coordinates                             */
    /**
     * *****************************************************************************************************************
     */
    private void getRandomCoordinates(Gameboard gameboard) {

        Random rand = new Random();
        // Get column number to try
        int col = rand.nextInt(6 + 1);

        // Make sure we can play that column, otherwise recursively re-call this method
        outerloop:
        for (int i = 0; i < gameboard.getRows(); i++) {
            if (gameboard.getSlots(col, i) == 0) {
                coordsToPlay[0] = col;
                coordsToPlay[1] = i;
                moveChosen = true;
                System.out.println("Coordinates set in random = " + coordsToPlay[0] + ", " + coordsToPlay[1]);
                break outerloop;
            }
        }

        if (!moveChosen) {
            getRandomCoordinates(gameboard);
        }
    }

    /**
     * ************** END Requirement 6.2.1.4 ****************************
     */
}

