package application;

public class Gameboard {

    private final int COLUMNS = 7;
    private final int ROWS = 6;
    public int[][] slots;
    public boolean winner;

    //Constructor
    Gameboard() {
        slots = new int[COLUMNS][ROWS];
        initializeBoard(slots);
        winner = false;
    }

    //Initialize all slots = 0
    public void initializeBoard(int[][] slots) {
        for (int i = 0; i < COLUMNS; i++) {
            for (int j = 0; j < ROWS; j++) {
                slots[i][j] = 0;
            }
        }
    }

    public int getSlots(int j, int i) {
        return slots[j][i];
    }

    public int getRows() {
        return ROWS;
    }

    public int getColumns() {
        return COLUMNS;
    }

    //Update the board after each move
    public void updateBoard(int[] coordinates, int currentPlayer) {
        int column = coordinates[0];
        int row = coordinates[1];
        slots[column][row] = currentPlayer;
    }

    //Check to see if we have a winner
    public void checkWinner(int currentPlayer) {
        if (!winner) {
            checkLateral();
        }
        if (!winner) {
            checkVertical();
        }
        if (!winner) {
            checkDiagonal(currentPlayer);
        }

    }

    private void checkLateral() {
        int playerOneCount = 0;
        int playerTwoCount = 0;

		//Since we'll have a nested loop, we'll label the outerloop as such so that we can specifically
        //break out of the outer loop, not just the inner loop.
        outerloop:
        //Starting at the lower left corner, go through each row looking for 5 in a row. 
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                switch (slots[j][i]) {
                    //if the slot = 0, neither player holds consecutive lateral slots.
                    case 0:
                        playerOneCount = 0;
                        playerTwoCount = 0;
                        break;
                    //If the slot = 1, increment player one's consecutive slots for this row
                    case 1:
                        playerOneCount++;
                        playerTwoCount = 0;
                        break;
                    //If the slot = 2, increment player two's consecutive slots for this row
                    case 2:
                        playerOneCount = 0;
                        playerTwoCount++;
                        break;
                }

				//If either value, 1 or 2, is found 5 consecutive times in one row, set the "winner" 
                //variable to true. This will cause the main loop in driver.java to exit, ending the game
                if (playerOneCount == 5 || playerTwoCount == 5) {
                    winner = true;
                    break outerloop;
                }
            }
            //Before moving to the next row up, reset both counts to 0
            playerOneCount = 0;
            playerTwoCount = 0;
        }
    }

    private void checkVertical() {
        int playerOneCount = 0;
        int playerTwoCount = 0;

		//Since we'll have a nested loop, we'll label the outer loop as such so that we can specifically
        //break out of the outer loop, not just the inner loop.
        outerloop:
        for (int i = 0; i < COLUMNS; i++) {
            for (int j = 0; j < ROWS; j++) {
                switch (slots[i][j]) {
                    //if the slot = 0, neither player holds consecutive lateral slots.
                    case 0:
                        playerOneCount = 0;
                        playerTwoCount = 0;
                        break;
                    //If the slot = 1, increment player one's consecutive slots for this column
                    case 1:
                        playerOneCount++;
                        playerTwoCount = 0;
                        break;
                    //If the slot = 2, increment player two's consecutive slots for this column
                    case 2:
                        playerOneCount = 0;
                        playerTwoCount++;
                        break;
                }
				//If either value, 1 or 2, is found 5 consecutive times in one column, set the "winner" 
                //variable to true. This will cause the main loop in driver.java to exit, ending the game
                if (playerOneCount == 5 || playerTwoCount == 5) {
                    winner = true;
                    break outerloop;
                }
            }
            //Before moving to the next column, reset both counts to 0
            playerOneCount = 0;
            playerTwoCount = 0;
        }
    }

    private void checkDiagonal(int currentPlayer) {

        //Check forwards but only go up to row 2 (array index 1) and as far as column 3 (array index 2)
        outerloop:
        for (int i = 0; i < 2; i++) {//Rows
            for (int j = 0; j < 3; j++) {//Columns
                if (slots[j][i] == currentPlayer) {
                    winner = checkRowsAboveForward(j, i, currentPlayer);
                    if (winner) {
                        break outerloop;
                    }
                }
            }
        }

        //If game wasn't won above, check the board for a diagonal win going backwards
        if (!winner) {
		//Check backwards starting at the bottom right but only go up to row 2 (array index 1)
            //and as far left as column 5 (array index 4)
            outerloop:
            for (int i = 0; i < 2; i++) {//Rows
                for (int j = 6; j > 3; j--) {//Columns
                    if (slots[j][i] == currentPlayer) {
                        winner = checkRowsAboveBackward(j, i, currentPlayer);
                        if (winner) {
                            break outerloop;
                        }
                    }
                }
            }
        }
    }

    private boolean checkRowsAboveForward(int j, int i, int currentPlayer) {
        for (int k = 1; k < 5; k++) {
            if (slots[j + k][i + k] != currentPlayer) {
                return false;
            }
        }
        return true;
    }

    private boolean checkRowsAboveBackward(int j, int i, int currentPlayer) {
        for (int k = 1; k < 5; k++) {
            if (slots[j - k][i + k] != currentPlayer) {
                return false;
            }
        }
        return true;
    }
}
