package application;

/* 	
 *   connectfive
 *   army ants - software engineering
 *   connectfive driver class
 *   v1.0
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class ConnectFive extends Application {

    private UI ui = new UI(); // create new UI instance
    private Gameboard gameboard = new Gameboard(); // create new Gameboard instance
    private ComputerPlayer computerPlayer = new ComputerPlayer(); // create new ComputerPlayer instance
    private Stage primaryStage; // create local stage variable

    @Override
    public void start(Stage stage) {

        // set local Stage variable to JavaFX-created stage argument
        primaryStage = stage;

        // create new Scene instance and set to UI defined base container, width, & height
        Scene scene = new Scene(ui.initUI(this), ui.WIDTH, ui.HEIGHT);

        // add ConnectFiveStyle css stylesheet to scene 
        scene.getStylesheets().add(getClass()
                .getResource("ConnectFiveStyle.css").toExternalForm());

        // set icon for window
        stage.getIcons().add(new Image(ConnectFive.class
                .getResourceAsStream("ConnectFive.png")));
        
        // set title for window
        stage.setTitle("ConnectFive!");

        // set window as not resizable
        stage.setResizable(false);

        // add scene to stage
        stage.setScene(scene);

        // display the stage
        stage.show();
    }

    // backup method if JavaFX start sequence fails in certain environments
    public static void main(String[] args) {
        launch(args);
    }

    // public method to allow access to local Gameboard instance
    public Boolean callGameboard(int[] coordinates, int player) {

        // add token to gameboard based on coordinates and player passed as parameters
        gameboard.updateBoard(coordinates, player);

        // check the current gameboard for winner with current player 
        gameboard.checkWinner(player);

        // return status of gameboard to calling method
        return gameboard.winner;
    }

    // public method to reset gameboard
    public void initGameboard() {

        gameboard.initializeBoard(gameboard.slots);
        gameboard.winner = false;
    }

    // local Stage getter
    public Stage getStage() {

        return this.primaryStage;
    }

    // local Gameboard getter
    public Gameboard getGameboard() {

        return this.gameboard;
    }

    // local ComputerPlayer getter
    public ComputerPlayer getComputerPlayer() {

        return this.computerPlayer;
    }
}
