package application;

/* 	
 *  connectfive
 *  army ants - software engineering
 *  user interface class
 *  v4.1
 */
import java.util.ArrayList;
import java.util.List;
import javafx.animation.FadeTransition;
import javafx.animation.FadeTransitionBuilder;
import javafx.animation.TranslateTransition;
import javafx.animation.TranslateTransitionBuilder;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageViewBuilder;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.PaneBuilder;
import javafx.util.Duration;

public class UI {

    private static ConnectFive driver;

    // constants and layout coordinates
    final private static double OPACITY_0 = 0.0, OPACITY_1 = 1.0;

    final private static int SCENE_WIDTH = 1000, SCENE_HEIGHT = 675,
            GAMEBOARD_WIDTH = 706, GAMEBOARD_HEIGHT = 664,
            GAMEBOARD_LAYOUT_X = 0, GAMEBOARD_LAYOUT_Y = 90,
            DIALOG_BOX_X = 300, DIALOG_BOX_Y = 175, DIALOG_BOX_WIDTH = 400,
            DIALOG_BOX_HEIGHT = 325, GAME_OPTIONS_TOP_PANE_WIDTH = 259,
            GAME_OPTIONS_TOP_PANE_HEIGHT = 299, GAME_OPTIONS_TOP_PANE_X = 741,
            GAME_OPTIONS_TOP_PANE_Y = 102,
            GAME_OPTIONS_BOTTOM_PANE_WIDTH = 258,
            GAME_OPTIONS_BOTTOM_PANE_HEIGHT = 145,
            GAME_OPTIONS_BOTTOM_PANE_X = 741, GAME_OPTIONS_BOTTOM_PANE_Y = 512,
            END_GAME_QUESTION_X = 10, END_GAME_QUESTION_Y = 67,
            END_GAME_YES_X = 51, END_GAME_YES_Y = 193, END_GAME_NO_X = 236,
            END_GAME_NO_Y = 193, EXIT_QUESTION_X = 24, EXIT_QUESTION_Y = 61,
            EXIT_YES_X = 51, EXIT_YES_Y = 193, EXIT_NO_X = 236,
            EXIT_NO_Y = 193, TITLE_X = 5, TITLE_Y = 36, PVP_BUTTON_X = 17,
            PVP_BUTTON_Y = 149, PVC_BUTTON_X = 17, PVC_BUTTON_Y = 211,
            EXIT_GAME_BUTTON_X = 112, EXIT_GAME_BUTTON_Y = 266,
            GAME_OPTIONS_TITLE_X = 12, GAME_OPTIONS_TITLE_Y = 48,
            CURRENT_PLAYER_LABEL_X = 29, CURRENT_PLAYER_LABEL_Y = 127,
            BLUE_PLAYER_LABEL_X = 28, BLUE_PLAYER_LABEL_Y = 158,
            RED_PLAYER_LABEL_X = 49, RED_PLAYER_LABEL_Y = 158,
            WINNER_LABEL_X = 9, WINNER_LABEL_Y = 87, END_GAME_BUTTON_X = 50,
            END_GAME_BUTTON_Y = 40, EXIT_BUTTON_X = 89, EXIT_BUTTON_Y = 91,
            NUM_COLUMNS = 7, NUM_ROWS = 6, COLUMN_0 = 0, COLUMN_1 = 1,
            COLUMN_2 = 2, COLUMN_3 = 3, COLUMN_4 = 4, COLUMN_5 = 5,
            COLUMN_6 = 6, ARROWS_Y = 40, COLUMNS_X[] = {45, 135, 225, 315,
                405, 495, 585}, ROWS_Y_DROP[] = {646, 556, 466, 376, 286,
                196, -80}, BLUE = 1, RED = 2, PVP = 1, PVC = 2,
            IN_GAME = 1, NO_GAME = 2, TOTAL_TOKENS = 42;

    // ui panes - contain/organize ui nodes
    private static Pane background, dialogPane, selectGameDialog,
            endGameDialog, exitDialog, gamePane, gameBoardPane,
            gameBoardTokenPane, gameBoardBlueArrowPane, gameBoardRedArrowPane,
            gameOptionsTopPane, gameOptionsBottomPane;

    // ui images
    private static ImageView exitQuestion, exitYes, exitNo, endGameQuestion,
            endGameYes, endGameNo, pvpButton, pvcButton, title,
            gameOptionsTitle, currentPlayerLabel, bluePlayerLabel,
            redPlayerLabel, blueWinnerLabel, redWinnerLabel, drawLabel, exitGameButton,
            endGameButton, newGameButton, exitButton, gameBoardShadow,
            gameBoardImage, blueToken, redToken;

    // list of lists - each list contains tokens for one column
    @SuppressWarnings("rawtypes")
    private static List<List> gameBoardTokens;

	// lists of grouped ui images/nodesn for token columns - column select arrow
    // buttons
    private static List<ImageView> blueArrows, redArrows, column0Tokens,
            column1Tokens, column2Tokens, column3Tokens, column4Tokens,
            column5Tokens, column6Tokens;

    // game/ui control variables
    private static int gameType, lastLoser = BLUE, exitType, currentPlayer,
            column, row, tokens;

    // final int values for reference inside anonymous inner classes
    final public int WIDTH = SCENE_WIDTH, HEIGHT = SCENE_HEIGHT;

    // method to access game driver class and pass game stage scene to driver
    public Pane initUI(ConnectFive d) {

        // initialize local driver class variable to calling class
        driver = d;

        // call setupScene() and return base container as scene to driver class
        return setupScene();
    }

    // method to initialize all ui components within game scene
    private static Pane setupScene() {

        // resource strings to access background images
        String backgroundString = ConnectFive.class.getResource(
                "metal_background.jpg").toExternalForm();
        String dialogBoxString = ConnectFive.class.getResource(
                "selectGameBox.png").toExternalForm();
        String gameOptionsBoxBottomString = ConnectFive.class.getResource(
                "gameOptionsBoxBottom.png").toExternalForm();
        String gameOptionsBoxTopString = ConnectFive.class.getResource(
                "gameOptionsBoxTop.png").toExternalForm();

        // build window background container
        background = PaneBuilder
                .create()
                .layoutX(0)
                .layoutY(0)
                .minWidth(SCENE_WIDTH)
                .minHeight(SCENE_HEIGHT)
                .maxWidth(SCENE_WIDTH)
                .maxHeight(SCENE_HEIGHT)
                .style("-fx-background-image:url(' " + backgroundString + "');")
                .styleClass("background").build();

        // build generic dialog container
        dialogPane = PaneBuilder.create().layoutX(0).layoutY(0)
                .minWidth(SCENE_WIDTH).minHeight(SCENE_HEIGHT)
                .maxWidth(SCENE_WIDTH).maxHeight(SCENE_HEIGHT).build();

        // build end game dialog container
        endGameDialog = PaneBuilder.create().layoutX(DIALOG_BOX_X)
                .layoutY(DIALOG_BOX_Y).minWidth(DIALOG_BOX_WIDTH)
                .minHeight(DIALOG_BOX_HEIGHT).maxWidth(DIALOG_BOX_WIDTH)
                .maxHeight(DIALOG_BOX_HEIGHT).opacity(OPACITY_0)
                .style("-fx-background-image:url(' " + dialogBoxString + "');")
                .styleClass("dialog-box").build();

        // build end game query imageview node
        endGameQuestion = ImageViewBuilder.create()
                .layoutX(END_GAME_QUESTION_X).layoutY(END_GAME_QUESTION_Y)
                //.image(new Image("application/endGameQuestion.png")).build();
                .image(new Image("application/endGameQuestion.png")).build();

        // build end game dialog imageview node for yes button
        endGameYes = ImageViewBuilder.create().layoutX(END_GAME_YES_X)
                .layoutY(END_GAME_YES_Y)
                .image(new Image("application/yes.png")).styleClass("yes")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        removeEndGameDialog();
                        removeGamepane();
                        clearGameboard();
                        showSelectGameDialog();
                    }
                ;
        }).build();

		// build end game dialog imageview node for no button
		endGameNo = ImageViewBuilder.create().layoutX(END_GAME_NO_X)
                .layoutY(END_GAME_NO_Y)
                .image(new Image("application/no.png")).styleClass("no")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        removeEndGameDialog();
                        showGamepane();
                    }
                ;
        }).build();

		// insert end game dialog nodes into parent container - endGameDialog
		endGameDialog.getChildren().addAll(endGameQuestion, endGameYes,
                endGameNo);

        // build exit dialog container
        exitDialog = PaneBuilder.create().layoutX(DIALOG_BOX_X)
                .layoutY(DIALOG_BOX_Y).minWidth(DIALOG_BOX_WIDTH)
                .minHeight(DIALOG_BOX_HEIGHT).maxWidth(DIALOG_BOX_WIDTH)
                .maxHeight(DIALOG_BOX_HEIGHT).opacity(OPACITY_0)
                .style("-fx-background-image:url(' " + dialogBoxString + "');")
                .styleClass("dialog-box").build();

        // build exit game query imageview node
        exitQuestion = ImageViewBuilder.create().layoutX(EXIT_QUESTION_X)
                .layoutY(EXIT_QUESTION_Y)
                .image(new Image("application/exitQuestion.png")).build();

        // build exit game dialog imageview node for yes button
        exitYes = ImageViewBuilder.create().layoutX(EXIT_YES_X)
                .layoutY(EXIT_YES_Y).image(new Image("application/yes.png"))
                .styleClass("yes")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        driver.getStage().close();
                    }
                ;
        }).build();

		// build exit game dialog imageview for no button
		exitNo = ImageViewBuilder.create().layoutX(EXIT_NO_X)
                .layoutY(EXIT_NO_Y).image(new Image("application/no.png"))
                .styleClass("no")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        removeExitDialog();
                        if (exitType == IN_GAME) {

                            showGamepane();
                        } else if (exitType == NO_GAME) {

                            showSelectGameDialog();
                        }
                    }
                ;
        }).build();

		// insert exit game dialog nodes into parent container - exitDialog
		exitDialog.getChildren().addAll(exitQuestion, exitYes, exitNo);

        // build select game dialog container
        selectGameDialog = PaneBuilder.create().layoutX(DIALOG_BOX_X)
                .layoutY(DIALOG_BOX_Y).minWidth(DIALOG_BOX_WIDTH)
                .minHeight(DIALOG_BOX_HEIGHT).maxWidth(DIALOG_BOX_WIDTH)
                .maxHeight(DIALOG_BOX_HEIGHT).opacity(OPACITY_0)
                .style("-fx-background-image:url(' " + dialogBoxString + "');")
                .styleClass("dialog-box").build();

        // build imageview for title node
        title = ImageViewBuilder.create().layoutX(TITLE_X).layoutY(TITLE_Y)
                .image(new Image("application/title.png"))
                .styleClass("title").build();

        /**
         * *****************************************************************************
         */
        /*                 REQUIREMENT 1.1 - Player vs Player button               */
        /**
         * *****************************************************************************
         */
        // build imageview node for player vs player button
        pvpButton = ImageViewBuilder.create().layoutX(PVP_BUTTON_X)
                .layoutY(PVP_BUTTON_Y)
                .image(new Image("application/pvpButton.png"))
                .styleClass("select-game-button")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        gameType = PVP;
                        removeSelectGameDialog();
                        initGame(lastLoser, PVP);
                        showGamepane();
                    }
                ;
        }).build();

		/*****************             End Requirement 1.1              ********************/
		
		
		/***********************************************************************************/
		/*               REQUIREMENT 1.2 - PLayer vs Computer button               */
		/***********************************************************************************/
		// build imageview node for player vs computer button
		pvcButton = ImageViewBuilder.create().layoutX(PVC_BUTTON_X)
                .layoutY(PVC_BUTTON_Y)
                .image(new Image("application/pvcButton.png"))
                .styleClass("select-game-button")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        gameType = PVC;
                        removeSelectGameDialog();
                        initGame(lastLoser, PVC);
                        showGamepane();
                    }
                ;
        }).build();
		/*****************             End Requirement 1.2		   ********************/
		
		/**************************************************************************************/
		/*               REQUIREMENT 1.3 - Show Exit button                          */
		/**************************************************************************************/
		// build imageview node for exit game button
		exitGameButton = ImageViewBuilder.create().layoutX(EXIT_GAME_BUTTON_X)
                .layoutY(EXIT_GAME_BUTTON_Y)
                .image(new Image("application/exitGame.png"))
                .styleClass("exit-game")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        exitType = NO_GAME;
                        removeSelectGameDialog();
                        showExitDialog();
                    }
                ;
        }).build();
		
		/*****************             End Requirement 1.3		   ********************/
		
		/**************************************************************************************/
		/*            REQUIREMENT 1.0 - Show game types and exit button             */
		/**************************************************************************************/
		// insert select game dialog nodes into parent container -
		// selectGameDialog
		selectGameDialog.getChildren().addAll(title, pvpButton, pvcButton,
                exitGameButton);

        // insert all dialogs into parent dialog pane container - dialogPane
        dialogPane.getChildren().addAll(selectGameDialog, exitDialog,
                endGameDialog);
        /**
         * **************** End Requirement 1.0              *******************
         */

        // build game container
        gamePane = PaneBuilder.create().minWidth(SCENE_WIDTH + 10)
                .minHeight(SCENE_HEIGHT + 10).opacity(OPACITY_0).build();

        // build game board container
        gameBoardPane = PaneBuilder.create().layoutX(25).layoutY(0)
                .minWidth(GAMEBOARD_WIDTH).minHeight(GAMEBOARD_HEIGHT).build();

        // build game token container
        gameBoardTokenPane = PaneBuilder.create().layoutX(0).layoutY(0)
                .minWidth(GAMEBOARD_WIDTH).minHeight(GAMEBOARD_HEIGHT).build();

        // build blue player select column button container
        gameBoardBlueArrowPane = PaneBuilder.create().layoutX(0).layoutY(0)
                .minWidth(GAMEBOARD_WIDTH).minHeight(GAMEBOARD_HEIGHT)
                .opacity(OPACITY_0).build();

        // build red player select column button container
        gameBoardRedArrowPane = PaneBuilder.create().layoutX(0).layoutY(0)
                .minWidth(GAMEBOARD_WIDTH).minHeight(GAMEBOARD_HEIGHT)
                .opacity(OPACITY_0).build();

        // build imageview node for game board
        gameBoardImage = ImageViewBuilder.create().layoutX(GAMEBOARD_LAYOUT_X)
                .layoutY(GAMEBOARD_LAYOUT_Y)
                .image(new Image("application/gameBoard3.png")).build();

        // build imageview node for game board shadow
        gameBoardShadow = ImageViewBuilder.create().layoutX(GAMEBOARD_LAYOUT_X)
                .layoutY(GAMEBOARD_LAYOUT_Y)
                .image(new Image("application/dropShadow.png")).build();

        // insert game board nodes into parent container - gameBoardPane
        gameBoardPane.getChildren().addAll(gameBoardShadow, gameBoardTokenPane,
                gameBoardBlueArrowPane, gameBoardRedArrowPane, gameBoardImage);

        // build top game options container
        gameOptionsTopPane = PaneBuilder
                .create()
                .layoutX(GAME_OPTIONS_TOP_PANE_X)
                .layoutY(GAME_OPTIONS_TOP_PANE_Y)
                .minWidth(GAME_OPTIONS_TOP_PANE_WIDTH)
                .minHeight(GAME_OPTIONS_TOP_PANE_HEIGHT)
                .maxWidth(GAME_OPTIONS_TOP_PANE_WIDTH)
                .maxHeight(GAME_OPTIONS_TOP_PANE_HEIGHT)
                .style("-fx-background-image:url(' " + gameOptionsBoxTopString
                        + "');").styleClass("game-options-pane").build();

        // build imageview node for top game options container title
        gameOptionsTitle = ImageViewBuilder.create()
                .layoutX(GAME_OPTIONS_TITLE_X).layoutY(GAME_OPTIONS_TITLE_Y)
                .image(new Image("application/title2.png"))
                .styleClass("title").build();

        // build imageview node for current player label
        currentPlayerLabel = ImageViewBuilder.create()
                .layoutX(CURRENT_PLAYER_LABEL_X)
                .layoutY(CURRENT_PLAYER_LABEL_Y)
                .image(new Image("application/currentPlayer.png")).build();

        // build imageview node for blue player label, current player display
        bluePlayerLabel = ImageViewBuilder.create()
                .layoutX(BLUE_PLAYER_LABEL_X).layoutY(BLUE_PLAYER_LABEL_Y)
                .opacity(OPACITY_0)
                .image(new Image("application/bluePlayer.png")).build();

        // build imageview node for red player label, current player display
        redPlayerLabel = ImageViewBuilder.create().layoutX(RED_PLAYER_LABEL_X)
                .layoutY(RED_PLAYER_LABEL_Y).opacity(OPACITY_0)
                .image(new Image("application/redPlayer.png")).build();

        // build imageview node for draw label
        drawLabel = ImageViewBuilder.create().layoutX(WINNER_LABEL_X)
                .layoutY(WINNER_LABEL_Y).opacity(OPACITY_0)
                .image(new Image("application/draw.png")).build();

        // build imageview node for red winner label
        blueWinnerLabel = ImageViewBuilder.create().layoutX(WINNER_LABEL_X)
                .layoutY(WINNER_LABEL_Y).opacity(OPACITY_0)
                .image(new Image("application/blueWin.png")).build();

        // build imageview node for red winner label
        redWinnerLabel = ImageViewBuilder.create().layoutX(WINNER_LABEL_X)
                .layoutY(WINNER_LABEL_Y).opacity(OPACITY_0)
                .image(new Image("application/redWin.png")).build();

		// insert top game option nodes into parent container -
        // gameOptionsTopPane
        gameOptionsTopPane.getChildren().addAll(gameOptionsTitle,
                blueWinnerLabel, redWinnerLabel, drawLabel, currentPlayerLabel,
                bluePlayerLabel, redPlayerLabel);

        /**
         * *********************************************************************************************
         */
        /*                          REQUIREMENT 2.0 - Submenu                           */
        /**
         * *********************************************************************************************
         */
        // build bottom game options container
        gameOptionsBottomPane = PaneBuilder
                .create()
                .layoutX(GAME_OPTIONS_BOTTOM_PANE_X)
                .layoutY(GAME_OPTIONS_BOTTOM_PANE_Y)
                .minWidth(GAME_OPTIONS_BOTTOM_PANE_WIDTH)
                .minHeight(GAME_OPTIONS_BOTTOM_PANE_HEIGHT)
                .maxWidth(GAME_OPTIONS_BOTTOM_PANE_WIDTH)
                .maxHeight(GAME_OPTIONS_BOTTOM_PANE_HEIGHT)
                .style("-fx-background-image:url(' "
                        + gameOptionsBoxBottomString + "');")
                .styleClass("game-options-pane").build();

        /*                  Requirement 2.1 - End game option            */
        // build imageview node for end game button
        endGameButton = ImageViewBuilder.create().layoutX(END_GAME_BUTTON_X)
                .layoutY(END_GAME_BUTTON_Y)
                .image(new Image("application/endGameBtn2.png"))
                .styleClass("end-game-button")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        showEndGameDialog();
                        dimGamepane();
                    }
                ;
        }).build();

		/*                Requirement 2.2 - New Game option              */
		// build imageview node for new game button
		newGameButton = ImageViewBuilder.create().layoutX(END_GAME_BUTTON_X)
                .layoutY(END_GAME_BUTTON_Y)
                .image(new Image("application/newGameBtn.png"))
                .styleClass("new-game-button").opacity(OPACITY_0)
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        clearGameboard();
                        showSelectGameDialog();
                        dimGamepane();
                    }
                ;
        }).build();

		/*                Requirement 2.3 - Exit Game option              */
		// build imageview node for exit game button
		exitButton = ImageViewBuilder.create().layoutX(EXIT_BUTTON_X)
                .layoutY(EXIT_BUTTON_Y)
                .image(new Image("application/exitButton3.png"))
                .styleClass("exit-button")
                .onMouseReleased(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent me) {

                        exitType = IN_GAME;
                        showExitDialog();
                        dimGamepane();
                    }
                ;
        }).build();

		// insert bottom game options nodes into parent container -
		// gameOptionsBottomPane
		gameOptionsBottomPane.getChildren().addAll(newGameButton,
                endGameButton, exitButton);

        /**
         * ******************* END Requirement 2.0                    **********************
         */
        // insert game nodes into parent container - gamePane
        gamePane.getChildren().addAll(gameBoardPane, gameOptionsTopPane,
                gameOptionsBottomPane);

        // insert game and dialog containers into parent container - background
        background.getChildren().addAll(gamePane, dialogPane);

        // display select game dialog
        showSelectGameDialog();

        // return parent container to driver class for stage scene
        return background;
    }

    /**
     * **********************************************************************************************************
     */
    /*                    REQUIREMENT 3.0 - Display empty game board                           */
    /**
     * **********************************************************************************************************
     */
    // method to initialize all ui containers and set up game for first player
    private static void initGame(int firstPlayer, int gameType) {

        // initialize gameboard
        driver.initGameboard();

        // set total tokens played to 0
        tokens = 0;

        // initialize the select column buttons
        setupBlueArrows();
        setupRedArrows();

        // set any winner labels to invisible and move to back
        blueWinnerLabel.toBack();
        blueWinnerLabel.setVisible(false);

        redWinnerLabel.toBack();
        redWinnerLabel.setVisible(false);

        // set current player label and player labels visible
        currentPlayerLabel.setVisible(true);
        bluePlayerLabel.setVisible(true);
        redPlayerLabel.setVisible(true);

		// set end game button to front and visible, new game to back and not
        // visible
        newGameButton.toBack();
        endGameButton.toFront();
        newGameButton.setOpacity(OPACITY_0);
        endGameButton.setOpacity(OPACITY_1);

        // create new ArrayList for holding column token lists
        gameBoardTokens = new ArrayList<>();

        // create new ArrayLists to hold individual column tokens
        column0Tokens = new ArrayList<>();
        column1Tokens = new ArrayList<>();
        column2Tokens = new ArrayList<>();
        column3Tokens = new ArrayList<>();
        column4Tokens = new ArrayList<>();
        column5Tokens = new ArrayList<>();
        column6Tokens = new ArrayList<>();

        // insert individual column ArrayLists into game board tokens ArrayList
        gameBoardTokens.add(COLUMN_0, column0Tokens);
        gameBoardTokens.add(COLUMN_1, column1Tokens);
        gameBoardTokens.add(COLUMN_2, column2Tokens);
        gameBoardTokens.add(COLUMN_3, column3Tokens);
        gameBoardTokens.add(COLUMN_4, column4Tokens);
        gameBoardTokens.add(COLUMN_5, column5Tokens);
        gameBoardTokens.add(COLUMN_6, column6Tokens);

        // start the game set with first player and game type
        startGame(firstPlayer, gameType);
    }

    /**
     * ********************* END Requirement 3.0 *****************************************************
     */
    /**
     * *************************************************************************************************
     */
    /*                          REQUIREMENT 5.0 - Start Game                             */
    /**
     * *************************************************************************************************
     */
	// start game and set up column arrow buttons based on first player/game
    // type selected
    private static void startGame(int firstPlayer, int gameType) {

        /*
         * initialize variables and display column selection arrow buttons for
         * pre-selected first player based on game type selected
         */
        if (gameType == PVP) {
            if (firstPlayer == BLUE) {

                currentPlayer = BLUE;

                // display blue arrows on ui
                showBlueArrows();

                // set and display current player label to blue
                switchPlayerLabel(BLUE);
            } else {

                currentPlayer = RED;

                // display red arrows on ui
                showRedArrows();

                // set and display current player label to red
                switchPlayerLabel(RED);
            }
        } else {

            if (firstPlayer == BLUE) {

                currentPlayer = BLUE;

                // display blue arrows on ui
                showBlueArrows();

                // set and display current player label to blue
                switchPlayerLabel(BLUE);
            } else {

                currentPlayer = RED;

                // set and display current player label to red
                switchPlayerLabel(RED);

                // call computer play method
                computerPlayerTurn();
            }
        }
    }

    /**
     * ****************** END Requirement 5.0    *********************************************
     */
    // run fade transition on node argument, fade to value argument
    private static void fade(Node n, double v) {

        FadeTransition ft = FadeTransitionBuilder.create().toValue(v)
                .duration(Duration.millis(250)).node(n).build();

        ft.play();
    }

    // display game board container on ui
    private static void showGamepane() {

        fade(gamePane, OPACITY_1);
    }

    // remove game board container from ui
    private static void removeGamepane() {

        fade(gamePane, OPACITY_0);
    }

    // dim game board container while shown on ui
    private static void dimGamepane() {

        fade(gamePane, 0.5);
    }

    // display select game dialog container on ui
    private static void showSelectGameDialog() {

        fade(selectGameDialog, OPACITY_1);
        selectGameDialog.toFront();
        dialogPane.toFront();
    }

    // remove select game dialog container from ui
    private static void removeSelectGameDialog() {

        fade(selectGameDialog, OPACITY_0);
        selectGameDialog.toBack();
        dialogPane.toBack();
    }

    // display end game dialog container on ui
    private static void showEndGameDialog() {

        fade(endGameDialog, OPACITY_1);
        endGameDialog.toFront();
        dialogPane.toFront();

    }

    // remove end game dialog container from ui
    private static void removeEndGameDialog() {

        fade(endGameDialog, OPACITY_0);
        endGameDialog.toBack();
        dialogPane.toBack();
    }

    // display exit game dialog container on ui
    private static void showExitDialog() {

        fade(exitDialog, OPACITY_1);
        exitDialog.toFront();
        dialogPane.toFront();
    }

    // remove exit game dialog container from ui
    private static void removeExitDialog() {

        fade(exitDialog, OPACITY_0);
        exitDialog.toBack();
        dialogPane.toBack();
    }

    // change the current player label to current player
    private static void switchPlayerLabel(int player) {

        drawLabel.setOpacity(OPACITY_0);

        if (player == RED) {

            // fade in red player label, fade out blue player label
            fade(redPlayerLabel, OPACITY_1);
            fade(bluePlayerLabel, OPACITY_0);
        } else {

            // fade in blue player label, fade out red player label
            fade(redPlayerLabel, OPACITY_0);
            fade(bluePlayerLabel, OPACITY_1);
        }
    }

    // clear data from game board arrays
    private static void clearGameboard() {

        // clear all labels from status container
        fade(redPlayerLabel, OPACITY_0);
        fade(bluePlayerLabel, OPACITY_0);
        fade(redWinnerLabel, OPACITY_0);
        fade(blueWinnerLabel, OPACITY_0);
        fade(redPlayerLabel, OPACITY_0);
        fade(drawLabel, OPACITY_0);

        // clear all tokens from gameboard array
        gameBoardTokens.clear();

        // clear token display container
        gameBoardTokenPane.getChildren().clear();

        // clear red arrow button container
        gameBoardRedArrowPane.getChildren().clear();

        // clear blue arrow button container
        gameBoardBlueArrowPane.getChildren().clear();
    }

    /**
     * ************************************************************************************************
     */
    /*          REQUIREMENT 4.0  Setup click event handlers for turn taking 	      */
    /**
     * ************************************************************************************************
     */
    // initialize and build blue column select button array
    private static void setupBlueArrows() {

        // initialize blue arrow array
        blueArrows = new ArrayList<>();

        // loop through each column creating a blue arrow button for each
        for (int i = 0; i < NUM_COLUMNS; i++) {

            final int col = i;

            blueArrows.add(
                    // build blue arrow button imageview
                    ImageViewBuilder.create().layoutX(COLUMNS_X[i])
                    .layoutY(ARROWS_Y)
                    .image(new Image("application/blueArrow2.png"))
                    .styleClass("blue-arrow")
                    .onMouseReleased(new EventHandler<MouseEvent>() {

                        @Override
                        public void handle(MouseEvent me) {
                            // hide blue arrow container when clicked
                            hideBlueArrows();
                            // drop blue token in selected column
                            dropBlueToken(col);
                        }
                    }).build());
        }

        // add blue arrow buttons to parent container
        gameBoardBlueArrowPane.getChildren().addAll(blueArrows);
    }

    // initialize and build red column select button array
    private static void setupRedArrows() {

        // initialize red arrow array
        redArrows = new ArrayList<>();

        // loop through each column creating a red arrow button for each
        for (int i = 0; i < NUM_COLUMNS; i++) {

            final int col = i;

            // build red arrow button imageview
            redArrows.add(ImageViewBuilder.create().layoutX(COLUMNS_X[i])
                    .layoutY(ARROWS_Y)
                    .image(new Image("application/redArrow2.png"))
                    .styleClass("red-arrow")
                    .onMouseReleased(new EventHandler<MouseEvent>() {

                        @Override
                        public void handle(MouseEvent me) {

                            // hide red arrow container when clicked
                            hideRedArrows();
                            // drop red token in selected column
                            dropRedToken(col);
                        }
                    ;
        }
        ).build());
		}

		// add red arrow buttons to parent container
		gameBoardRedArrowPane.getChildren().addAll(redArrows);
    }

    /**
     * ********************* END Requirement 4.0  **********************************************************
     */
    /**
     * ******************************************************************************************************
     */
    /*            REQUIREMENT 6.2 - Display current player's arrows above columns                */
    /**
     * ******************************************************************************************************
     */
    // display blue column select arrow buttons currently available
    private static void showBlueArrows() {

        for (int i = 0; i < gameBoardTokens.size(); i++) {

            // if column is full, set blue arrow button for column to invisible
            if (gameBoardTokens.get(i).size() == NUM_ROWS) {
                blueArrows.get(i).setVisible(false);
            }
        }

        // display blue arrow button container
        gameBoardBlueArrowPane.setVisible(true);
        gameBoardBlueArrowPane.toFront();
        fade(gameBoardBlueArrowPane, OPACITY_1);
    }

    // display red column select arrow buttons currently available
    private static void showRedArrows() {

        for (int i = 0; i < gameBoardTokens.size(); i++) {

            // if column is full, set red arrow button for column to invisible
            if (gameBoardTokens.get(i).size() == NUM_ROWS) {
                redArrows.get(i).setVisible(false);
            }
        }

        // display red arrow button container
        gameBoardRedArrowPane.setVisible(true);
        gameBoardRedArrowPane.toFront();
        fade(gameBoardRedArrowPane, OPACITY_1);
    }

    /**
     * ********************* END Requirement 6.2  **********************************************************
     */

    /**
     * ******************************************************************************************************
     */
    /*             REQUIREMENT 6.1 - Hide current player's arrows above columns               */
    /**
     * ******************************************************************************************************
     */
    // hide blue arrow button container
    private static void hideBlueArrows() {

        gameBoardBlueArrowPane.setVisible(false);
        gameBoardBlueArrowPane.toBack();
        gameBoardBlueArrowPane.setOpacity(OPACITY_0);
    }

    // hide red arrow button container
    private static void hideRedArrows() {

        gameBoardRedArrowPane.setVisible(false);
        gameBoardRedArrowPane.toBack();
        gameBoardRedArrowPane.setOpacity(OPACITY_0);
    }

    /**
     * ********************* END Requirement 6.1  **********************************************************
     */

    // show new game button and hide end game button
    private static void showNewGameButton() {

        newGameButton.toFront();
        endGameButton.toBack();
        fade(newGameButton, OPACITY_1);
        fade(endGameButton, OPACITY_0);
    }

    /**
     * *****************************************************************************************************
     */
    /*              REQUIREMENT 6.3 - Drop current player's token into chosen column            */
    /**
     * *****************************************************************************************************
     */
    // drop blue token into the game board in the selected column
    private static void dropBlueToken(int column) {

        // build a new blue token and place above selected column
        blueToken = ImageViewBuilder.create().layoutX(COLUMNS_X[column])
                .layoutY(ROWS_Y_DROP[6]).styleClass("token")
                .image(new Image("application/blueToken3.png")).build();

        // add new blue token to selected column
        addTokenToColumn(blueToken, column);
    }

    // drop red token into the game board in the selected column
    private static void dropRedToken(int column) {

        // build a new red token and place above select column
        redToken = ImageViewBuilder.create().layoutX(COLUMNS_X[column])
                .layoutY(ROWS_Y_DROP[6]).styleClass("token")
                .image(new Image("application/redToken3.png")).build();

        // add new red token to selected column
        addTokenToColumn(redToken, column);
    }

    // drop token as imageview in selected column
    @SuppressWarnings("unchecked")
    private static void addTokenToColumn(ImageView token, int col) {

        // set global column variable to selected column
        column = col;

        // get total number of tokens already in selected column
        row = gameBoardTokens.get(column).size();

        // add token to gameBoardTokens array in selected column
        gameBoardTokens.get(column).add(token);

        // add token imageview to parent container for display
        gameBoardTokenPane.getChildren().add(token);

        // drop token to selected row from initial position
        TranslateTransition tt = TranslateTransitionBuilder.create()
                .toY(ROWS_Y_DROP[row]).duration(Duration.millis(600))
                .node(token).build();

        tt.play();

		// when transition to row is complete, call and run play evaluation
        // method
        tt.setOnFinished(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                // increment total tokens played
                tokens++;
                // process token drop for win, draw, continue
                processColumnSelection(column, row);
            }
        });
    }

    /**
     * ************************* END Requirement 6.3          ******************************
     */

    /**
     * *********************************************************************************************
     */
    /*                    REQUIREMENT 6.2.1  - Computer Player Turn                   */
    /**
     * *********************************************************************************************
     */
    // for pvc game types, run computer play
    private static void computerPlayerTurn() {

        int coords[] = driver.getComputerPlayer().chooseMove(driver.getGameboard());

        hideRedArrows();
        dropRedToken(coords[0]);
    }

    /**
     * *********************** END Requirement 6.2.1    ***************************************
     */

    /**
     * ********************************************************************************************
     */
    /*                         REQUIREMENT 6.0 - Take a turn   	          */
    /**
     * ********************************************************************************************
     */
    // for current column selection and player, process last play
    private static void processColumnSelection(int column, int row) {

        /*             REQUIREMENT 6.4.2 - If it's a winning move             */
        if (evaluateDrop(currentPlayer, column, row)) {

            // current player has won game - process game win
            currentPlayerLabel.setVisible(false);
            redPlayerLabel.setVisible(false);
            bluePlayerLabel.setVisible(false);
            gameBoardRedArrowPane.setVisible(false);
            gameBoardBlueArrowPane.setVisible(false);

            if (currentPlayer == BLUE) {

                // display blue player wins label
                blueWinnerLabel.toFront();
                blueWinnerLabel.setVisible(true);
                fade(blueWinnerLabel, OPACITY_1);

                /*        REQUIREMENT 6.4.2.1 - Show new game button             */
                // show new game button and hide end game button
                showNewGameButton();
                /*              END Requirement 6.4.2.1             */
                // set next player to current loser
                lastLoser = RED;
            } else {

                // display red player wins label
                redWinnerLabel.toFront();
                redWinnerLabel.setVisible(true);
                fade(redWinnerLabel, OPACITY_1);

                // show new game button and hide end game button
                showNewGameButton();

                // set next player to current loser
                lastLoser = BLUE;
            }
            /*         END Requirement 6.4.2             */
        } else if (tokens == TOTAL_TOKENS) {
            /*      	Requirement 6.4.3 - If it's a draw game		    */
            // current player has won game - process game win
            currentPlayerLabel.setVisible(false);
            redPlayerLabel.setVisible(false);
            bluePlayerLabel.setVisible(false);
            gameBoardRedArrowPane.setVisible(false);
            gameBoardBlueArrowPane.setVisible(false);

            // display draw game label
            drawLabel.toFront();
            drawLabel.setVisible(true);
            fade(drawLabel, OPACITY_1);

            /*              REQUIREMENT 6.4.3.1 - Show new game button         */
            // show new game button and hide end game button
            showNewGameButton();
            /*              END Requirement 6.4.3.1                            */

            // set next player to current loser
            if (lastLoser == BLUE) {
                lastLoser = RED;
            } else {
                lastLoser = BLUE;
            }
        } else {
            /*              REQUIREMENT 6.4.4 - Switch players                */
            // no winner - continue game
            if (gameType == PVP) {

                if (currentPlayer == BLUE) {

                    currentPlayer = RED;
                    switchPlayerLabel(currentPlayer);
                    showRedArrows();
                } else {

                    currentPlayer = BLUE;
                    switchPlayerLabel(currentPlayer);
                    showBlueArrows();
                }
            } else {

                if (currentPlayer == BLUE) {

                    currentPlayer = RED;
                    switchPlayerLabel(currentPlayer);
                    computerPlayerTurn();
                } else {

                    currentPlayer = BLUE;
                    switchPlayerLabel(currentPlayer);
                    showBlueArrows();
                }
            }
        }
        /*                         END Requirement 6.4.4                           */
    }

    /**
     * ********************* END Requirement 6.0 *****************************************
     */

    /**
     * **************************************************************************************
     */
    /*	        	REQUIREMENT 6.4 - Process move played              */
    /**
     * **************************************************************************************
     */
    // pass current player, coordinates to driver class/gameboard to check for win
    private static boolean evaluateDrop(int p, int c, int r) {

        // create coordinates array to pass to gameboard class in driver
        int[] coordinates = {c, r};

        /*    REQUIREMENT 6.4.1 - Call Gameboard class' method to check for a winner    */
        // pass current play coordinates to gameboard instance in driver and get results
        boolean winner = driver.callGameboard(coordinates, p);
        /*              END Requirement 6.4.1                                                                                 */

        // return results from gameboard
        return winner;
    }
    /**
     * ********************* END Requirement 6.4 ****************************************
     */
}
